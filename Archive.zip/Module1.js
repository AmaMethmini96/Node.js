let x = () =>{

    console.log('ama');
};

let y = () =>{
    console.log('pasindu');
};

module.exports.z = x;
module.exports.p = y;