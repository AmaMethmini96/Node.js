const a = require('./Module1');

a.z();
a.p();